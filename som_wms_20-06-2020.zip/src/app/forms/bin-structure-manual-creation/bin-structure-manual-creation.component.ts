

import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, FormArray, NgForm } from '@angular/forms'
import { MatDialog } from '@angular/material/dialog';
import { BinAutoCreateTemplateComponent } from '../../tables/bin-auto-create-template/bin-auto-create-template.component';

@Component({
  selector: 'app-bin-structure-manual-creation',
  templateUrl: './bin-structure-manual-creation.component.html',
  styleUrls: ['./bin-structure-manual-creation.component.css']
})
export class BinStructureManualCreationComponent implements OnInit{
  addForm: FormGroup;

  rows: FormArray;
  itemForm: FormGroup;
  selectedTemplate: any;
  isTemplateSelect: boolean = false;
  constructor(private fb: FormBuilder, public dialog: MatDialog) {

    this.addForm = this.fb.group({
      items: [null, Validators.required],
      items_value: ['no', Validators.required]
    });

    this.rows = this.fb.array([]);

  }
  getControls() {
    return (this.addForm.get('rows') as FormArray).controls;  }

  ngOnInit() {


    

    
        this.addForm.get("items_value").setValue("yes");

        this.addForm.addControl('rows', this.rows);

  }

  onAddRow() {
   
    
    this.rows.push(this.createItemFormGroup());

  }

  onRemoveRow(rowIndex:number){
    this.rows.removeAt(rowIndex);
  }

  createItemFormGroup(): FormGroup {
    return this.fb.group({
      binNumber: null,
    
    });
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(BinAutoCreateTemplateComponent, {
      width: '600px',
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.selectedTemplate = result;
     
      } else {
        return;
      }


    });
  }

  onRadioChange(event) {
    if(event.value == '1') {
      this.isTemplateSelect = false;
      this.selectedTemplate ='';
    } else {
     this.isTemplateSelect = true;
    }

  }


}

