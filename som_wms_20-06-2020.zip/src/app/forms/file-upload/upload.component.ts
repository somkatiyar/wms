import { Component, ChangeDetectionStrategy } from '@angular/core';


@Component({
  templateUrl: './upload.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./upload.scss']
})
export class UploadComponent {
  
}
