
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';
import { MatTableDataSource } from '@angular/material/table';
import { SelectionModel } from '@angular/cdk/collections';
import { MatDialog } from '@angular/material/dialog';
import { ToMaterialPopupComponent } from '../../tables/to-material-popup/to-material-popup.component';


/**
 * @title Stepper that displays errors in the steps
 */
@Component({
  selector: 'app-to-within-warehouse',
  templateUrl: './to-within-warehouse.component.html',
  styleUrls: ['./to-within-warehouse.component.css'],
  providers: [{
    provide: STEPPER_GLOBAL_OPTIONS, useValue: { showError: true }
  }]
})


export class TOWithinWarehouseComponent implements OnInit {


  materials: any = [
    { storageTypeNo: "sty-1", storageTypeName: "STORAGE TYPE 1", sectionNo: "03", sectionName: "SECTION 3", storageBinCellNo: "012-L02-007", qtyInBinCell: 30, unit: "BUNDLES" },
    { storageTypeNo: "sty-2", storageTypeName: "STORAGE TYPE 2", sectionNo: "05", sectionName: "SECTION 5", storageBinCellNo: "012-L02-009", qtyInBinCell: 10, unit: "BUNDLES" },


  ];

  groupList: any;
  isTO: boolean = false;
  isGroupListData: boolean = false;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  destinationForm: FormGroup;
  currentDate = new Date();
  selectedMaterial: any;
  constructor(private _formBuilder: FormBuilder, public dialog: MatDialog) {


  }

  ngOnInit() {
 
    this.firstFormGroup = this._formBuilder.group({
      warehouseName: ['', Validators.required],
      pickingDateTime: [this.currentDate, Validators.required],
      movementType: ['', Validators.required],
      material: ['', Validators.required],
      materialDesc: ['', Validators.required],
      matQty: ['', Validators.required],
      matUnit: ['', Validators.required],
    });
    this.secondFormGroup = this._formBuilder.group({
      toDate: ['', Validators.required],
      toType: ['', Validators.required],
      matCount: ['', Validators.required],
      warehouse: ['', Validators.required],

      movementType: ['', Validators.required],
      material: ['', Validators.required],
      materialDesc: ['', Validators.required],
      matQty: ['', Validators.required],
      matUnit: ['', Validators.required],

    });

  
  }



  clickNextOnFirstScreen() {
    this.secondFormGroup.controls['toDate'].setValue(this.currentDate.getDate());
    this.secondFormGroup.controls['toType'].setValue(this.firstFormGroup.controls['movementType'].value);
    this.secondFormGroup.controls['matCount'].setValue(this.firstFormGroup.controls['matQty'].value);
    this.secondFormGroup.controls['warehouse'].setValue(this.firstFormGroup.controls['warehouseName'].value);
    this.secondFormGroup.controls['movementType'].setValue(this.firstFormGroup.controls['movementType'].value);
    this.secondFormGroup.controls['material'].setValue(this.firstFormGroup.controls['material'].value);
    this.secondFormGroup.controls['materialDesc'].setValue(this.firstFormGroup.controls['materialDesc'].value);
    this.secondFormGroup.controls['matQty'].setValue(this.firstFormGroup.controls['matQty'].value);
    this.secondFormGroup.controls['matUnit'].setValue(this.firstFormGroup.controls['matUnit'].value);

  }

  openDialog(): void {
    const dialogRef = this.dialog.open(ToMaterialPopupComponent, {
      width: '600px',
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.selectedMaterial = result;

      } else {
        return;
      }


    });
  }


 

 

  saveData() {

  }




}
