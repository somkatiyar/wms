export interface Contact {
  contactimg: string,
  contactname: string,
  contactpost: string,
  contactadd: string,
  contactno: string
  contactinstagram: string
  contactlinkedin: string
  contactfacebook: string
}