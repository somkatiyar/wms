export class Note {
    color: string;
    title: string;
    datef: Date;
}

