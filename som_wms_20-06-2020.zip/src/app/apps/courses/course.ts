export class course {
    Id: number;
    courseType: string;
    Time: string;
    courseName: string;
    Update: string;
} 