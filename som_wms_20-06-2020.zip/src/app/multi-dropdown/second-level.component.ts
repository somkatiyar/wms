import { Component, AfterViewInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-second-level',
  templateUrl: './second-level.component.html'
})
export class SecondLevelComponent implements AfterViewInit {
  ngAfterViewInit() {}
}
